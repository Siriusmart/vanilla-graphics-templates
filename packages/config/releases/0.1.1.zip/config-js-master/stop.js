let config = module.require("./");

config.forceWriteAll();
