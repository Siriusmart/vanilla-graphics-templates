Missing events:
|Event|Reason|
|---|---|
|ClientPickBlockApplyCallback|Could not find on Fabric GitHub|
