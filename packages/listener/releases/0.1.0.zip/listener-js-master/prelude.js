prelude.eval(
    "let {addEventListener, removeEventListener} = module.globals.listener",
);
