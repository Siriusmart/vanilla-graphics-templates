- setTimeout(callback, milliseconds, name?)
- setInterval(callback, milliseconds, name?)

If you name your timers you will have a better time debugging.

```js
let timeout = setTimeout(() => {
  console.log("Timeout complete");
}, 1000);

let interval = setInterval(() => {
  console.log("Interval complete");
}, 1000);

// you could use clearInterval and clearTimeout
// but its simpler if you just do
timeout.cancel();
interval.cancel();
```
