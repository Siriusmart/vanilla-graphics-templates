let { TimerTask, Timer } = java.util;

function setTimeout(callback, millis = 0, name = "An unnamed timer") {
    let task = new JavaAdapter(TimerTask, {
        run: callback,
    });
    let timer = new Timer(name);

    timer.schedule(task, millis);

    return {
        timer,
        cancel: function () {
            this.timer.cancel();
        },
    };
}

function clearTimeout(cancellable) {
    cancellable.cancel();
}

module.exports = {
    setTimeout,
    clearTimeout
};
