let { TimerTask, Timer } = java.util;

function setInterval(callback, millis = 0, name = "An unnamed interval") {
    let task = new JavaAdapter(TimerTask, {
        run: callback,
    });
    let timer = new Timer(name);

    timer.scheduleAtFixedRate(task, 0, millis);

    return {
        timer,
        cancel: function () {
            this.timer.cancel();
        },
    };
}

function clearInterval(cancellable) {
    cancellable.cancel();
}

module.exports = {
    setInterval,
    clearInterval,
};
