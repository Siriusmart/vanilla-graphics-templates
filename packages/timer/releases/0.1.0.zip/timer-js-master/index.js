module.exports = {};

Object.assign(module.exports, module.require("./setTimeout"));
Object.assign(module.exports, module.require("./setInterval"));
