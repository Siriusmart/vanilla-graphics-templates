module.exports = {}

Object.assign(module.exports, module.require("./sync"));
Object.assign(module.exports, module.require("./callback"));