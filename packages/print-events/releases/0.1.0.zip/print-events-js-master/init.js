let command = require("command");
let fs = require("fs");

command.register({
    name: "printEvents",

    execute: () => {
        let { events } = require("listener");
        let keys = Object.keys(events);

        fs.mkdirSync("storage/print-events");

        let name = `storage/print-events/export-${new Date().toISOString()}.json`;

        fs.writeFileSync(
            name,
            JSON.stringify(
                {
                    keys,
                },
                null,
                2,
            ),
        );

        console.info(`Export saved to ${name}`);
    },
});
