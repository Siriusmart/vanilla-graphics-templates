The `/printEvents` command saves a list of all available events to a JSON file.
