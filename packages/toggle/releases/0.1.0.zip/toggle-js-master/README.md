- Toggle requires a **name**.
- onActivate and onDeactivate are optional.
- Then you can optionally have event names as function to listen to the event, these functions can take in the appropriate parameters. Note that you will need to have the event provider as dependency (e.g. **fabric-api-events**)

```js
let toggle = require("toggle");

toggle.register({
  name: "HelloToggle",

  onActivate() {
    console.log("activated");
  },

  onDeactivate() {
    console.log("deactivated");
  },

  startClientWorldTickEvent() {
    console.log(1);
  },
});
```

## Commands

- /toggle (alias to /toggle list)
- /toggle on [names...]
- /toggle off [names...]
