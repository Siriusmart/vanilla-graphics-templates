let command = require("command");
const { execute } = require("./command/list");

let buildOnCommand = module.require("./command/on");
let buildOffCommand = module.require("./command/off");
let list = module.require("./command/list");

command.register({
    name: "toggle",
    execute: list.execute,

    subcommands: {
        list,
        on: buildOnCommand(false),
        off: buildOffCommand(false),
        "on-menu": buildOnCommand(true),
        "off-menu": buildOffCommand(true),
        // restart: {},
        // status: {},
    },
});
