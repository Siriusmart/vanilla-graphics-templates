let listener = require("listener");
let config = require("config");

// { toggleName: [listOfEvents] }
let listenings = {};
// { toggleName: [toggleContent, listeners] }
let registeredToggles = {};
let activatedToggles = new Set((config.load("toggle") ?? {}).active ?? []);

function shouldBeActive(name) {
    return activatedToggles.has(name + "");
}

function isActive(name) {
    return shouldBeActive(name) && registeredToggles[name] != undefined;
}

let isStopping = false;

// unchecked activate
function _activate(name, modifyState) {
    if (isStopping) return;

    let [toggle, listeners] = registeredToggles[name];
    if (modifyState) {
        activatedToggles.add(name);
        config.save("toggle", { active: Array.from(activatedToggles) });
    }

    if (toggle.onActivate) toggle.onActivate();

    listenings[name] = [];

    for (let [key, f] of listeners) {
        listenings[name].push(addEventListener(key, f));
    }
}

// unchecked deactivate
function _deactivate(name, modifyState) {
    let wasActive = isActive(name);

    if (modifyState) {
        activatedToggles.delete(name);
        config.save("toggle", { active: Array.from(activatedToggles) });
    }

    if (wasActive) {
        if (listenings[name]) {
            for (let listener of listenings[name]) {
                listener.cancel();
            }

            delete listenings[name];
        }

        if (registeredToggles[name][0].onDeactivate)
            registeredToggles[name][0].onDeactivate();
    }
}

function activate(name, modifyState = true) {
    if (registeredToggles[name] == undefined) {
        throw new Error(
            `Toggle "${name}" is not activated because it has not been registered.`,
        );
    }

    if (isActive(name)) return false;

    _activate(name, modifyState);
    return true;
}

function deactivate(name, modifyState = true) {
    if (registeredToggles[name] == undefined) {
        throw new Error(
            `Toggle "${name}" is not deactivated because it has not been registered.`,
        );
    }

    if (!activatedToggles.has(name)) return false;

    _deactivate(name, modifyState);
    return true;
}

function register(toggle) {
    if (toggle.name === undefined)
        throw new Error("Attempt to register a toggle with no name");

    let activated = shouldBeActive(toggle.name);
    if (isActive(toggle.name)) deactivate(toggle.name);
    activatedToggles.delete(toggle.name);

    let listeners = [];
    for (let [name, handle] of Object.entries(toggle)) {
        if (listener.getByName(name)) {
            listeners.push([name, handle]);
        }
    }

    registeredToggles[toggle.name] = [toggle, listeners];

    if (activated) {
        activate(toggle.name);
    }
}

function exists(name) {
    return registeredToggles[name] != undefined;
}

function stopAll() {
    config.save("toggle", { active: Array.from(activatedToggles) });
    isStopping = true;

    for (let name of Array.from(activatedToggles)) {
        deactivate(name, false);
    }

    isStopping = false;
}

function getActive() {
    return Object.keys(registeredToggles).filter((name) =>
        activatedToggles.has(name),
    );
}

function getInactive() {
    return Object.keys(registeredToggles).filter(
        (name) => !activatedToggles.has(name),
    );
}

function getAll() {
    return Object.keys(registeredToggles);
}

module.exports = {
    activate,
    deactivate,
    register,
    stopAll,
    exists,
    isActive,
    getActive,
    getInactive,
    getAll,

    get toggles() {
        return Object.keys(registeredToggles);
    },
};
