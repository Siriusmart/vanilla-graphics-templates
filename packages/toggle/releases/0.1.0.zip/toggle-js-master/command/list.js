let toggle = module.require("../");
let text = require("text");

let previousText;

function list() {
    if (previousText) previousText.remove();

    previousText = text.sendText(
        [
            {
                content: "[",
                color: "#999933",
            },
            {
                content: `List of All Toggles`,
                color: "#ffbb55",
            },
            {
                content: "]",
                color: "#999933",
            },
        ].concat(
            toggle
                .getAll()
                .sort()
                .flatMap((entry) =>
                    toggle.isActive(entry)
                        ? [
                              "\n",
                              {
                                  content: "[⭘]",
                                  hover: `Deactivate \u00A7a\u00A7o${entry}`,
                                  click: `/toggle off-menu ${entry}`,
                                  color: "#888888",
                              },
                              ` \u00A78[\u00A7a\u00A7lActive\u00A78] \u00A7a${entry}`,
                          ]
                        : [
                              "\n",
                              {
                                  content: "[⏻]",
                                  hover: `Activate \u00A7c\u00A7o${entry}`,
                                  click: `/toggle on-menu ${entry}`,
                                  color: "#888888",
                              },
                              ` \u00A78[\u00A7c\u00A7lInactive\u00A78] \u00A7c${entry}`,
                          ],
                ),
        ),
    );
}

module.exports = {
    execute: list,
};
