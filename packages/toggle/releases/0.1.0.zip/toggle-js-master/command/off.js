let toggle = module.require("../");
let text = require("text");

let list = module.require("./list").execute;

let maxDepth = 256;

function handle(menu, ...names) {
    for (let name of names) {
        if (!toggle.exists(name)) {
            console.error(`No toggles with name '${name}'`);
        } else if (toggle.deactivate(name)) {
            text.sendText({
                content: `\u00A78[\u00A7c\u00A7lDeactivated\u00A78] \u00A7c${name}`,
                hover: `Activate \u00A7o${name}`,
                click: `/toggle on ${name}`,
            });
        } else {
            console.warn(`${name} is not active, nothing changed.`);
        }
    }

    if (menu) list();
}

function offSuggest(...previous) {
    previous = new Set(previous);
    return toggle.getActive().filter((name) => !previous.has(name));
}

function buildOffCommand(menu, currentDepth = 1) {
    if (currentDepth == 1) {
        return {
            type: "string",
            execute: function (...args) {
                handle(menu, args);
            },
            suggests: offSuggest,
            args: {
                toggle1: buildOffCommand(menu, currentDepth + 1),
            },
        };
    }

    let command = {
        type: "string",
        execute: function (...args) {
            handle(menu, args);
        },
        suggests: offSuggest,
    };

    if (currentDepth <= maxDepth) {
        command.args = {};
        command.args[`toggle${currentDepth}`] = buildOffCommand(
            menu,
            currentDepth + 1,
        );
    }

    return command;
}

module.exports = buildOffCommand;
