let toggle = module.require("../");
let text = require("text");

let list = module.require("./list").execute;

let maxDepth = 256;

function handle(menu, ...names) {
    for (let name of names) {
        if (!toggle.exists(name)) {
            console.error(`No toggles with name '${name}'`);
        } else if (toggle.activate(name)) {
            text.sendText({
                content: `\u00A78[\u00A7a\u00A7lActivated\u00A78] \u00A7a${name}`,
                hover: `Deactivate \u00A7o${name}`,
                click: `/toggle off ${name}`,
            });
        } else {
            console.warn(`${name} is already activated, nothing changed.`);
        }
    }

    if (menu) list();
}

function onSuggest(...previous) {
    previous = new Set(previous);
    return toggle.getInactive().filter((name) => !previous.has(name));
}

function buildOnCommand(menu, currentDepth = 1) {
    if (currentDepth == 1) {
        return {
            type: "string",
            execute: function (...args) {
                handle(menu, args);
            },
            suggests: onSuggest,
            args: {
                toggle1: buildOnCommand(menu, currentDepth + 1),
            },
        };
    }

    let command = {
        type: "string",
        execute: function (...args) {
            handle(menu, args);
        },
        suggests: onSuggest,
    };

    if (currentDepth <= maxDepth) {
        command.args = {};
        command.args[`toggle${currentDepth}`] = buildOnCommand(
            menu,
            currentDepth + 1,
        );
    }

    return command;
}

module.exports = buildOnCommand;
