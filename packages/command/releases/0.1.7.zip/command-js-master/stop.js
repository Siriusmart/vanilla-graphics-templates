let { deregisterAll } = module.require("./");

deregisterAll();
