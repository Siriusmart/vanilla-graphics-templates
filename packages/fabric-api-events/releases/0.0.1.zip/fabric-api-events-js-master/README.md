I have defined all the client events and some of the server events.

Some server events are left out because they are currently not needed, as I am only testing on client side at the moment.
