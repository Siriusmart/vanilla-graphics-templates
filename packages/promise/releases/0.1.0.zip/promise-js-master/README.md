```js
let promise = Promise(() => {
    // some completable task
    return result;
});

promise
    .then(res => {
        // do something with it
        return newRes;
    })
    .catch(err => {
        // do something with it
        return recovered;
    })
    .then(res => {
        console.log(res);
    });
```
