let CompletableFuture = java.util.concurrent.CompletableFuture;

function Promise(task) {
    let promise = {
        state: "pending",
        waiting: [],
        res: undefined,

        chainLock: false,

        then(f) {
            this.waiting.push({ type: "then", f });
            this.startChain();
            return this;
        },

        catch(f) {
            this.waiting.push({ type: "catch", f });
            this.startChain();
            return this;
        },

        findErrorHandler() {
            while (this.waiting.length !== 0) {
                let item = this.waiting.shift();

                if (item.type == "catch") {
                    return item.f;
                }
            }
        },

        handleError(error) {
            this.chainLock = true;

            let handler = this.findErrorHandler();

            if (handler) {
                this.res = handler(error);
            } else {
                this.chainLock = false;
                throw error;
            }
        },

        startChain() {
            if (this.chainLock || this.state == "pending") return;
            this.chainLock = true;

            while (this.waiting.length !== 0) {

                let item = this.waiting.shift();

                if (item.type == "then") {
                    try {
                        this.res = item.f(this.res);
                    } catch (error) {
                        this.handleError(error);
                    }
                }
            }

            this.chainLock = false;
        }
    };

    CompletableFuture.runAsync(() => {
        try {
            promise.res = task();
        } catch (error) {
            promise.handleError(error);
            promise.state = "ok";
            promise.startChain();
            return;
        }

        promise.state = "ok";
        promise.startChain();
    });

    return promise;
}

module.exports = {
    Promise,
};