module.exports = {};

Object.assign(module.exports, module.require("./getLocalManifests"));
Object.assign(module.exports, module.require("./getOutdated"));
Object.assign(module.exports, module.require("./findPackage"));
Object.assign(module.exports, module.require("./config"));
