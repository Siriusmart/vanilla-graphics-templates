module.exports = {};

Object.assign(module.exports, module.require("./getIndex"));
Object.assign(module.exports, module.require("./getManifest"));
Object.assign(module.exports, module.require("./getVersions"));