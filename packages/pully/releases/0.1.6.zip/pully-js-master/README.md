```js
let pully = require("pully");

pully.pullSync(["packages", "to", "pull"], whetherToPrintOutputs);
```
