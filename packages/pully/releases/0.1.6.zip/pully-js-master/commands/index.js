let buildInstallCommand = module.require("./install");
let buildUninstallCommand = module.require("./uninstall");

module.exports = {
    buildInstallCommand,
    buildUninstallCommand,
};
