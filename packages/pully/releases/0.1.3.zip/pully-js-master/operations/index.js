module.exports = {};

Object.assign(module.exports, module.require("./pull"));
Object.assign(module.exports, module.require("./remove"));
