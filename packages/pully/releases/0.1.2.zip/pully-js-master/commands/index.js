let buildInstallCommand = module.require("./install");

module.exports = {
    buildInstallCommand,
};
