module.exports = {
    filterNotOutdated: module.require("./filterNotOutdated"),
}

Object.assign(module.exports, module.require("./dependencies"));