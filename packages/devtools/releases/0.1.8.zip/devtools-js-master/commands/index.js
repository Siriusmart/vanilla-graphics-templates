module.exports = {};

Object.assign(module.exports, module.require("./new"));
Object.assign(module.exports, module.require("./eval"));
Object.assign(module.exports, module.require("./open"));
Object.assign(module.exports, module.require("./close"));
Object.assign(module.exports, module.require("./suggestions"));
