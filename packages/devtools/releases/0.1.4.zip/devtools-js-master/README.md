# devtools!

- /devtools create &lt;name&gt; - creates a package
- /devtools eval &lt;at&gt; &lt;expression&gt; - evaluate expression in package.
