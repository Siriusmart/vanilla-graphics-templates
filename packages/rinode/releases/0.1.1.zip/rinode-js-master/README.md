Package bundle providing Node.js features.

```js
let fs = require("fs");
let object = require("./file.json");

console.log(content);
fetch(url, options);
setTimeout(callback, delay)
```

See individual packages for docs.
