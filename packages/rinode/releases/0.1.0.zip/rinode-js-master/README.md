Package bundle providing Node.js features.

```js
let fs = require("fs");
let object = require("./file.json");

console.log(content);
fetch(url, options);
```

See individual packages for docs.