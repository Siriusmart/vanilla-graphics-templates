```js
let { extract, extractSync } = require("extract-zip");

// extract returns a Promise
// extractSync blocks and does the thing

function extract(source, target, overwrite = false)
function extractSync(source, target, overwrite = false)

extractSync({ path: "./test.zip" }, "./unzipped");

// source could also be
// - { bytes: byte[] }
// - { url: String }
```