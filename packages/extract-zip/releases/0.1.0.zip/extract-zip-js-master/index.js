let FabricLoader = net.fabricmc.loader.api.FabricLoader;
let FileUtils = org.apache.commons.io.FileUtils;
let ZipInputStream = java.util.zip.ZipInputStream;
let Files = java.nio.file.Files;
let FileInputStream = java.io.FileInputStream;
let ByteArrayInputStream = java.io.ByteArrayInputStream;

let basePath = FabricLoader.getInstance()
    .getConfigDir().resolve("jscore");

let { fetchSync } = require('fetch');

function unzip(is, targetDir, overwrite) {
    targetDir = basePath.resolve(targetDir);

    if (overwrite && Files.exists(targetDir)) {
        FileUtils.deleteQuietly(targetDir.toFile());
    }

    let zipIn = new ZipInputStream(is);

    for (let ze; (ze = zipIn.getNextEntry()) != null;) {
        resolvedPath = targetDir.resolve(ze.getName()).normalize();
        if (!resolvedPath.startsWith(targetDir)) {
            // see: https://snyk.io/research/zip-slip-vulnerability
            throw new Error("Unzip error: Entry with an illegal path: "
                + ze.getName());
        }
        if (ze.isDirectory()) {
            Files.createDirectories(resolvedPath);
        } else {
            Files.createDirectories(resolvedPath.getParent());
            Files.copy(zipIn, resolvedPath);
        }
    }
}

function extractSync(source, target, overwrite = false) {
    if (source.path) {
        let path = basePath.resolve(source.path);
        let is = new FileInputStream(path.toFile());

        unzip(is, target, overwrite);
    } else if (source.bytes) {
        let is = new ByteArrayInputStream(source.bytes);

        unzip(is, target, overwrite);
    } else if (source.url) {
        let res = fetchSync(source.url);

        return extractSync({ bytes: res.bytes() }, target, overwrite);
    } else {
        throw new Error(`No source in ${JSON.stringify(source)}`);
    }
}

function extract(source, target, overwrite = false) {
    return Promise(() => extractSync(source, target, overwrite));
}

module.exports = {
    extractSync,
    extract,
};