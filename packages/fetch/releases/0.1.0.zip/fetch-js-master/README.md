- fetch
- fetchSync

```js
fetch(url, options)
    .then(res => res.text())
    .then(console.log)
    .catch(console.error);