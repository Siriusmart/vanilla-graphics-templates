let CompletableFuture = java.util.concurrent.CompletableFuture;

let HttpClient = java.net.http.HttpClient;
let HttpRequest = java.net.http.HttpRequest;
let HttpResponse = java.net.http.HttpResponse;
let URI = java.net.URI;

let client = HttpClient.newBuilder()
    .followRedirects(HttpClient.Redirect.NORMAL)
    .build();

let { Response } = module.require("./response");
let { Promise } = module.require("/modules/promise");

function fetchSync(url, options = {}) {
    options.method ??= "GET";

    let bodyPublisher;

    // TODO body type
    if (options.body) {
        bodyPublisher = HttpRequest.BodyPublishers.ofString(options.body);
    } else {
        bodyPublisher = HttpRequest.BodyPublishers.noBody();
    }

    let requestBuilder = HttpRequest.newBuilder()
        .uri(URI.create(url))
        .method(options.method, bodyPublisher)

    for (let [key, value] of Object.values(options.headers ?? {})) {
        requestBuilder = requestBuilder.header(key, value);
    }

    let request = requestBuilder.build();
    let response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());

    return Response(response);
}


function fetch(url, options = {}) {
    return Promise(() => fetchSync(url, options));
}

module.exports = {
    fetchSync,
    fetch,
}