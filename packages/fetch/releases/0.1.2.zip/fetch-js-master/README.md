- fetch
- fetchSync

```js
fetch(url, options)
    .then(res => res.text())
    .then(console.log)
    .catch(console.error);
```

## Response

- res.bytes() -> byte[]
- res.text(encoding = "utf8") -> String
- res.json(encoding = "utf8") -> Object
- res.status() -> int
- res.statusText() -> String
- res.url() -> String
- res.redirected() -> Boolean
- res.ok() -> Boolean
- Response.getStatusText(code: int) -> String