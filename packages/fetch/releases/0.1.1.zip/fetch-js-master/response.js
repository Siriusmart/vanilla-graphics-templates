let StandardCharsets = java.nio.charset.StandardCharsets;

function fromEncoding(encoding) {
    if (encoding instanceof java.lang.String) {
        encoding = '' + encoding;
    }

    if (typeof encoding != "string") {
        return encoding;
    }

    switch (encoding.toLowerCase()) {
        case "utf8":
        case "utf-8":
            return StandardCharsets.UTF_8;
        case "utf16":
        case "utf-16":
            return StandardCharsets.UTF_16;
        case "ascii":
            return StandardCharsets.US_ASCII;
        case "iso-8859-1":
            return StandardCharsets.ISO_8859_1;
        default:
            throw new Error(`Unknown encoding ${encoding}`);
    }
}

function Response(httpResponse) {
    // HttpResponse<byte[]>
    return {
        httpResponse,

        // byte[]
        bytes() {
            return httpResponse.body();
        },

        text(encoding = "utf8") {
            return new java.lang.String(this.bytes(), fromEncoding(encoding));
        },

        json(encoding = "utf8") {
            return JSON.parse(this.text(encoding));
        },

        // headers() {
        //     return httpResponse.getAllHeaders();
        // },

        status() {
            return httpResponse.statusCode();
        },

        statusText() {
            return Response.getStatusText(this.status());
        },

        url() {
            return httpResponse.request().uri().toString();
        },

        redirected() {
            return httpResponse.previousResponse().isPresent();
        },

        ok() {
            return 200 <= this.status() && this.status() < 300;
        }
    };
}

Response.getStatusText = (code) => {
        switch (code) {
            // 1xx Informational
            case 100:
                return "Continue";
            case 101:
                return "Switching Protocols";

            // 2xx Success
            case 200:
                return "OK";
            case 201:
                return "Created";
            case 202:
                return "Accepted";
            case 203:
                return "Non-Authoritative Information";
            case 204:
                return "No Content";
            case 205:
                return "Reset Content";
            case 206:
                return "Partial Content";

            // 3xx Redirection
            case 300:
                return "Multiple Choices";
            case 301:
                return "Moved Permanently";
            case 302:
                return "Found";
            case 303:
                return "See Other";
            case 304:
                return "Not Modified";
            case 305:
                return "Use Proxy";
            case 307:
                return "Temporary Redirect";
            case 308:
                return "Permanent Redirect";

            // 4xx Client Error
            case 400:
                return "Bad Request";
            case 401:
                return "Unauthorized";
            case 402:
                return "Payment Required";
            case 403:
                return "Forbidden";
            case 404:
                return "Not Found";
            case 405:
                return "Method Not Allowed";
            case 406:
                return "Not Acceptable";
            case 407:
                return "Proxy Authentication Required";
            case 408:
                return "Request Timeout";
            case 409:
                return "Conflict";
            case 410:
                return "Gone";
            case 411:
                return "Length Required";
            case 412:
                return "Precondition Failed";
            case 413:
                return "Payload Too Large";
            case 414:
                return "URI Too Long";
            case 415:
                return "Unsupported Media Type";
            case 416:
                return "Range Not Satisfiable";
            case 417:
                return "Expectation Failed";
            case 418:
                return "I'm a teapot";
            case 421:
                return "Misdirected Request";
            case 422:
                return "Unprocessable Entity";
            case 423:
                return "Locked";
            case 424:
                return "Failed Dependency";
            case 426:
                return "Upgrade Required";
            case 428:
                return "Precondition Required";
            case 429:
                return "Too Many Requests";
            case 431:
                return "Request Header Fields Too Large";

            // 5xx Server Error
            case 500:
                return "Internal Server Error";
            case 501:
                return "Not Implemented";
            case 502:
                return "Bad Gateway";
            case 503:
                return "Service Unavailable";
            case 504:
                return "Gateway Timeout";
            case 505:
                return "HTTP Version Not Supported";
            case 506:
                return "Variant Also Negotiates";
            case 507:
                return "Insufficient Storage";
            case 508:
                return "Loop Detected";
            case 510:
                return "Not Extended";
            case 511:
                return "Network Authentication Required";

            default:
                return "Unknown status code";
        }
}

module.exports = {
    Response,
};