let { MinecraftClient } = Yarn.net.minecraft.client;

let client = MinecraftClient.getInstance();

function message(content, history = false) {
    if (client.player == null) return false;
    if (history) client.inGameHud.getChatHud().addToMessageHistory(content);
    client.player.networkHandler.sendChatMessage(content);
    return true;
}

function command(content, history = false) {
    if (client.player == null) return false;
    if (history)
        client.inGameHud.getChatHud().addToMessageHistory(`/${content}`);
    client.player.networkHandler.sendChatCommand(content);
    return true;
}

module.exports = {
    message,
    command,
};
