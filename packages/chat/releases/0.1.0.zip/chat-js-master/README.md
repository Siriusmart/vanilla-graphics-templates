```js
let chat = require("chat");

chat.message(content: string);
chat.command(content: string); // without the slash
chat.message(content: string, history: boolean); // whether to add to chat history
chat.command(content: string, history: boolean);
```
