prelude.eval("let Yarn = Packages.ws.siri.jscore.mapping.JSPackage.getRoot();");
prelude.eval("let unwrap = Packages.ws.siri.jscore.runtime.Runtime.unwrap;");
prelude.eval(
    "function wrap(source, force) { return force ? Packages.ws.siri.jscore.runtime.Runtime.wrap(source) : Packages.ws.siri.jscore.runtime.Runtime.autoWrap(source) }",
);
